"use strict";

const GRID_SIZE = 15;
const CELL_SIZE = 40;
const CANVAS_SIZE = GRID_SIZE * CELL_SIZE;
const LEVELS = [
  {
    name: "The Entry",
    difficulty: "EASY",
    requiredKeys: 3,
    timeLimit: 75,
    enemySpeed: 0.65,
    rows: [
      "111111111111111",
      "100000000050001",
      "101111011111101",
      "100100010001001",
      "101101110101101",
      "100001000100001",
      "111101011101111",
      "100001000001001",
      "101111011101101",
      "100000010000001",
      "101111010111101",
      "100000010000001",
      "102000030000041",
      "100000500000001",
      "111111111111111",
    ],
  },
  {
    name: "Split Current",
    difficulty: "MEDIUM",
    requiredKeys: 4,
    timeLimit: 65,
    enemySpeed: 0.52,
    rows: [
      "111111111111111",
      "100000000000001",
      "101111011111101",
      "100001000010001",
      "101101110110101",
      "100100050100001",
      "111101011101111",
      "100001010000001",
      "101111010111101",
      "100000010000001",
      "101101110110101",
      "100100000010001",
      "102000030000041",
      "100005000000001",
      "111111111111111",
    ],
  },
  {
    name: "The Switchback",
    difficulty: "HARD",
    requiredKeys: 5,
    timeLimit: 58,
    enemySpeed: 0.45,
    rows: [
      "111111111111111",
      "100000050000001",
      "101111011111101",
      "100001000010001",
      "111101110110111",
      "100000010000001",
      "101111010111101",
      "100100010100001",
      "101101110101101",
      "100000000000001",
      "101111011111101",
      "100010000010001",
      "102000030000041",
      "100005000050001",
      "111111111111111",
    ],
  },
  {
    name: "Dead-End District",
    difficulty: "VERY HARD",
    requiredKeys: 6,
    timeLimit: 50,
    enemySpeed: 0.38,
    rows: [
      "111111111111111",
      "100000500000001",
      "101111011111101",
      "101000010000101",
      "101011110111101",
      "100010000010001",
      "111110111110111",
      "100000010000001",
      "101111010111101",
      "100001000010001",
      "111101110110111",
      "100000050000001",
      "102000030000041",
      "100005000500001",
      "111111111111111",
    ],
  },
  {
    name: "Final Pursuit",
    difficulty: "FINAL",
    requiredKeys: 7,
    timeLimit: 42,
    enemySpeed: 0.3,
    rows: [
      "111111111111111",
      "100000050000001",
      "101111011111101",
      "100000010000001",
      "111101110110111",
      "100001000010001",
      "101111011111101",
      "100010050010001",
      "101110111011101",
      "100000000000001",
      "111111010111111",
      "100000010000001",
      "102000030000041",
      "100005000500001",
      "111111111111111",
    ],
  },
];

const canvas = document.querySelector("#maze-canvas");
const context = canvas.getContext("2d");
const screenOverlay = document.querySelector("#screen-overlay");
const pathToggle = document.querySelector("#path-toggle");
const ui = {
  level: document.querySelector("#level-number"),
  levelName: document.querySelector("#level-name"),
  difficulty: document.querySelector("#difficulty-label"),
  state: document.querySelector("#state-label"),
  score: document.querySelector("#score-value"),
  keys: document.querySelector("#keys-value"),
  keysRequired: document.querySelector("#keys-required"),
  health: document.querySelector("#health-value"),
  time: document.querySelector("#time-value"),
  pathLength: document.querySelector("#path-length"),
  message: document.querySelector("#game-message"),
  completeScore: document.querySelector("#complete-score"),
  completeKeys: document.querySelector("#complete-keys"),
  overScore: document.querySelector("#over-score"),
  overDetail: document.querySelector("#over-detail"),
  winScore: document.querySelector("#win-score"),
};

const DIRECTIONS = [
  { x: 0, y: -1 },
  { x: 0, y: 1 },
  { x: -1, y: 0 },
  { x: 1, y: 0 },
];

function pointKey(point) {
  return `${point.x},${point.y}`;
}

function manhattanDistance(first, second) {
  return Math.abs(first.x - second.x) + Math.abs(first.y - second.y);
}

function isWalkable(grid, point) {
  return point.x >= 0 && point.y >= 0 && point.x < GRID_SIZE && point.y < GRID_SIZE && grid[point.y][point.x] !== 1;
}

function findPath(start, goal, maze) {
  if (!start || !goal || !isWalkable(maze.grid, start) || !isWalkable(maze.grid, goal)) return [];

  const startKey = pointKey(start);
  const goalKey = pointKey(goal);
  const openList = [start];
  const openKeys = new Set([startKey]);
  const closedList = new Set();
  const cameFrom = new Map();
  const gScore = new Map([[startKey, 0]]);
  const fScore = new Map([[startKey, manhattanDistance(start, goal)]]);

  while (openList.length > 0) {
    let bestIndex = 0;
    for (let index = 1; index < openList.length; index += 1) {
      const currentKey = pointKey(openList[index]);
      const bestKey = pointKey(openList[bestIndex]);
      if (fScore.get(currentKey) < fScore.get(bestKey)) bestIndex = index;
    }

    const current = openList.splice(bestIndex, 1)[0];
    const currentKey = pointKey(current);
    openKeys.delete(currentKey);
    if (currentKey === goalKey) {
      const path = [current];
      let stepKey = currentKey;
      while (cameFrom.has(stepKey)) {
        stepKey = cameFrom.get(stepKey);
        const [x, y] = stepKey.split(",").map(Number);
        path.push({ x, y });
      }
      return path.reverse();
    }

    closedList.add(currentKey);
    for (const direction of DIRECTIONS) {
      const neighbor = { x: current.x + direction.x, y: current.y + direction.y };
      const neighborKey = pointKey(neighbor);
      if (!isWalkable(maze.grid, neighbor) || closedList.has(neighborKey)) continue;

      const tentativeG = gScore.get(currentKey) + 1;
      if (tentativeG >= (gScore.get(neighborKey) ?? Infinity)) continue;

      cameFrom.set(neighborKey, currentKey);
      gScore.set(neighborKey, tentativeG);
      fScore.set(neighborKey, tentativeG + manhattanDistance(neighbor, goal));
      if (!openKeys.has(neighborKey)) {
        openList.push(neighbor);
        openKeys.add(neighborKey);
      }
    }
  }
  return [];
}

function generateKeyPositions(maze, numberOfKeys) {
  const reachable = new Map();
  const queue = [maze.playerStart];
  while (queue.length > 0) {
    const point = queue.shift();
    const key = pointKey(point);
    if (reachable.has(key) || !isWalkable(maze.grid, point)) continue;
    reachable.set(key, point);
    for (const direction of DIRECTIONS) queue.push({ x: point.x + direction.x, y: point.y + direction.y });
  }

  const reserved = new Set([pointKey(maze.playerStart), pointKey(maze.enemyStart), pointKey(maze.exit)]);
  const candidates = [...reachable.values()].filter((point) => !reserved.has(pointKey(point)) && !maze.coins.has(pointKey(point)));
  if (candidates.length < numberOfKeys) throw new Error(`Not enough reachable spaces for keys in ${maze.name}`);

  const distances = new Map();
  for (const start of candidates) {
    const startKey = pointKey(start);
    const distanceMap = new Map([[startKey, 0]]);
    const distanceQueue = [start];
    while (distanceQueue.length > 0) {
      const point = distanceQueue.shift();
      const pointDistance = distanceMap.get(pointKey(point));
      for (const direction of DIRECTIONS) {
        const next = { x: point.x + direction.x, y: point.y + direction.y };
        const nextKey = pointKey(next);
        if (reachable.has(nextKey) && !distanceMap.has(nextKey)) {
          distanceMap.set(nextKey, pointDistance + 1);
          distanceQueue.push(next);
        }
      }
    }
    distances.set(startKey, distanceMap);
  }

  const createsStraightLine = (candidate, selected) => {
    for (let firstIndex = 0; firstIndex < selected.length; firstIndex += 1) {
      for (let secondIndex = firstIndex + 1; secondIndex < selected.length; secondIndex += 1) {
        const first = selected[firstIndex];
        const second = selected[secondIndex];
        const crossProduct = (second.x - first.x) * (candidate.y - first.y) - (second.y - first.y) * (candidate.x - first.x);
        if (crossProduct === 0) return true;
      }
    }
    return false;
  };

  for (const minimumSpacing of [6, 5, 4, 3, 2]) {
    for (let attempt = 0; attempt < 100; attempt += 1) {
      const selected = [candidates[Math.floor(Math.random() * candidates.length)]];
      while (selected.length < numberOfKeys) {
        const options = [];
        for (const candidate of candidates) {
          if (selected.some((point) => point.x === candidate.x || point.y === candidate.y)) continue;
          if (selected.some((point) => Math.max(Math.abs(point.x - candidate.x), Math.abs(point.y - candidate.y)) < 2)) continue;
          if (createsStraightLine(candidate, selected)) continue;
          const candidateDistances = distances.get(pointKey(candidate));
          const spacing = Math.min(...selected.map((point) => candidateDistances.get(pointKey(point))));
          if (spacing >= minimumSpacing) options.push({ point: candidate, spacing });
        }

        if (options.length === 0) break;
        const greatestSpacing = Math.max(...options.map((option) => option.spacing));
        const farthest = options.filter((option) => option.spacing === greatestSpacing);
        selected.push(farthest[Math.floor(Math.random() * farthest.length)].point);
      }
      if (selected.length === numberOfKeys) return selected;
    }
  }
  throw new Error(`Cannot spread ${numberOfKeys} keys across ${maze.name}`);
}

class Maze {
  constructor(levelData) {
    this.name = levelData.name;
    this.requiredKeys = levelData.requiredKeys;
    this.timeLimit = levelData.timeLimit;
    this.enemySpeed = levelData.enemySpeed;
    this.grid = levelData.rows.map((row) => [...row].map(Number));
    this.coins = new Set();
    this.playerStart = null;
    this.enemyStart = null;
    this.exit = null;

    this.grid.forEach((row, y) => row.forEach((cell, x) => {
      if (cell === 2) this.playerStart = { x, y };
      if (cell === 3) this.enemyStart = { x, y };
      if (cell === 4) this.exit = { x, y };
      if (cell === 5) this.coins.add(`${x},${y}`);
    }));

    this.keyPositions = generateKeyPositions(this, this.requiredKeys);
  }
}

class MazeGame {
  constructor() {
    this.state = "MENU";
    this.levelIndex = 0;
    this.score = 0;
    this.health = 3;
    this.message = "";
    this.messageUntil = 0;
    this.showPath = false;
    this.lastFrame = 0;
    this.enemyAccumulator = 0;
    this.lastPlayerMove = 0;
    this.loadLevel(0);
    this.bindEvents();
    this.applyState("MENU");
    this.updateHud();
    requestAnimationFrame((time) => this.frame(time));
  }

  loadLevel(index) {
    this.levelIndex = index;
    const level = LEVELS[index];
    this.maze = new Maze(level);
    this.player = { ...this.maze.playerStart };
    this.enemy = { ...this.maze.enemyStart };
    this.activeKeys = new Set(this.maze.keyPositions.map(pointKey));
    this.collectedKeys = new Set();
    this.coins = new Set(this.maze.coins);
    this.timeLeft = level.timeLimit;
    this.enemyAccumulator = 0;
    this.message = "";
    this.path = findPath(this.enemy, this.player, this.maze);
    this.updateHud();
  }

  bindEvents() {
    document.querySelectorAll("[data-action]").forEach((button) => {
      button.addEventListener("click", () => this.handleAction(button.dataset.action));
    });
    pathToggle.addEventListener("click", () => {
      this.showPath = !this.showPath;
      pathToggle.setAttribute("aria-pressed", String(this.showPath));
      pathToggle.classList.toggle("is-on", this.showPath);
    });
    window.addEventListener("keydown", (event) => this.handleKeydown(event));
  }

  handleAction(action) {
    if (action === "start" || action === "retry") {
      this.score = 0;
      this.health = 3;
      this.showPath = false;
      pathToggle.setAttribute("aria-pressed", "false");
      this.loadLevel(0);
      this.applyState("PLAYING");
    } else if (action === "how") {
      this.applyState("HOW_TO_PLAY");
    } else if (action === "ai") {
      this.applyState("AI_INFO");
    } else if (action === "menu") {
      this.applyState("MENU");
    } else if (action === "next") {
      if (this.levelIndex < LEVELS.length - 1) {
        this.loadLevel(this.levelIndex + 1);
        this.applyState("PLAYING");
      }
    }
  }

  handleKeydown(event) {
    const keyMap = {
      ArrowUp: [0, -1],
      KeyW: [0, -1],
      ArrowDown: [0, 1],
      KeyS: [0, 1],
      ArrowLeft: [-1, 0],
      KeyA: [-1, 0],
      ArrowRight: [1, 0],
      KeyD: [1, 0],
    };
    if (this.state !== "PLAYING" || !keyMap[event.code]) return;
    event.preventDefault();
    const now = performance.now();
    if (now - this.lastPlayerMove < 105) return;
    this.lastPlayerMove = now;
    this.movePlayer(...keyMap[event.code]);
  }

  movePlayer(dx, dy) {
    const next = { x: this.player.x + dx, y: this.player.y + dy };
    if (!isWalkable(this.maze.grid, next)) return;
    this.player = next;
    this.collectAtPlayer();

    if (this.player.x === this.maze.exit.x && this.player.y === this.maze.exit.y) {
      if (this.collectedKeys.size >= this.maze.requiredKeys) {
        this.completeLevel();
        return;
      }
      this.setMessage("Collect all keys first!");
    }

    this.path = findPath(this.enemy, this.player, this.maze);
    if (this.samePosition(this.player, this.enemy)) this.handleEnemyCollision();
    this.updateHud();
  }

  collectAtPlayer() {
    const key = pointKey(this.player);
    if (this.activeKeys.delete(key)) {
      this.collectedKeys.add(key);
      this.score += 20;
      this.setMessage("Key collected  +20");
    }
    if (this.coins.delete(key)) {
      this.score += 10;
      this.setMessage("Coin collected  +10");
    }
  }

  setMessage(message) {
    this.message = message;
    this.messageUntil = performance.now() + 1700;
    ui.message.textContent = message;
    ui.message.hidden = false;
  }

  completeLevel() {
    if (this.state !== "PLAYING" || this.collectedKeys.size < this.maze.requiredKeys) return;
    this.score += 100 + Math.max(0, Math.floor(this.timeLeft)) * 5;
    if (this.levelIndex === LEVELS.length - 1) {
      ui.winScore.textContent = `FINAL SCORE: ${String(this.score).padStart(4, "0")}`;
      this.applyState("WIN");
    } else {
      ui.completeScore.textContent = `SCORE: ${String(this.score).padStart(4, "0")}`;
      ui.completeKeys.textContent = `KEYS COLLECTED: ${this.collectedKeys.size}/${this.maze.requiredKeys}`;
      this.applyState("LEVEL_COMPLETE");
    }
    this.updateHud();
  }

  moveEnemy() {
    this.path = findPath(this.enemy, this.player, this.maze);
    if (this.path.length > 1) this.enemy = { ...this.path[1] };
    if (this.samePosition(this.enemy, this.player)) this.handleEnemyCollision();
    this.path = findPath(this.enemy, this.player, this.maze);
  }

  handleEnemyCollision() {
    if (this.state !== "PLAYING") return;
    this.health -= 1;
    if (this.health <= 0) {
      ui.overScore.textContent = `SCORE: ${String(this.score).padStart(4, "0")}`;
      ui.overDetail.textContent = `LEVEL ${this.levelIndex + 1} · KEYS ${this.collectedKeys.size}/${this.maze.requiredKeys}`;
      this.applyState("GAME_OVER");
      return;
    }
    this.player = { ...this.maze.playerStart };
    this.enemy = { ...this.maze.enemyStart };
    this.path = findPath(this.enemy, this.player, this.maze);
    this.setMessage(`Caught! ${this.health} health remaining`);
    this.updateHud();
  }

  samePosition(first, second) {
    return first.x === second.x && first.y === second.y;
  }

  applyState(state) {
    this.state = state;
    document.body.dataset.state = state;
    const hasOverlay = state !== "PLAYING";
    screenOverlay.hidden = !hasOverlay;
    screenOverlay.querySelectorAll("[data-screen]").forEach((panel) => {
      panel.hidden = panel.dataset.screen !== state;
    });
    ui.state.textContent = state.replaceAll("_", " ");
    if (state === "PLAYING") {
      this.message = "";
      ui.message.hidden = true;
    }
    this.updateHud();
  }

  updateHud() {
    const level = LEVELS[this.levelIndex];
    ui.level.textContent = String(this.levelIndex + 1).padStart(2, "0");
    ui.levelName.textContent = level.name.toUpperCase();
    ui.difficulty.textContent = level.difficulty;
    ui.score.textContent = String(this.score).padStart(4, "0");
    ui.keys.textContent = String(this.collectedKeys?.size ?? 0);
    ui.keysRequired.textContent = `/${level.requiredKeys}`;
    ui.health.textContent = `${"● ".repeat(Math.max(0, this.health)).trim()}${this.health < 3 ? ` ${"○ ".repeat(3 - Math.max(0, this.health)).trim()}` : ""}`;
    ui.health.setAttribute("aria-label", `${Math.max(0, this.health)} health remaining`);
    ui.time.textContent = String(Math.max(0, Math.ceil(this.timeLeft ?? level.timeLimit)));
    ui.pathLength.textContent = this.path?.length ? `${this.path.length - 1} TILES` : "NO ROUTE";
  }

  frame(timestamp) {
    const delta = this.lastFrame ? Math.min(timestamp - this.lastFrame, 100) : 0;
    this.lastFrame = timestamp;
    this.update(delta, timestamp);
    this.draw(timestamp);
    requestAnimationFrame((time) => this.frame(time));
  }

  update(delta, timestamp) {
    if (this.state !== "PLAYING") return;
    if (this.samePosition(this.player, this.maze.exit) && this.collectedKeys.size >= this.maze.requiredKeys) {
      this.completeLevel();
      return;
    }

    this.enemyAccumulator += delta;
    const enemyInterval = 1400 * this.maze.enemySpeed;
    if (this.enemyAccumulator >= enemyInterval) {
      this.enemyAccumulator = 0;
      this.moveEnemy();
      if (this.state !== "PLAYING") return;
    }

    this.timeLeft -= delta / 1000;
    if (this.timeLeft <= 0) {
      this.timeLeft = 0;
      ui.overScore.textContent = `SCORE: ${String(this.score).padStart(4, "0")}`;
      ui.overDetail.textContent = "TIME EXPIRED";
      this.applyState("GAME_OVER");
    }

    if (this.message && timestamp >= this.messageUntil) {
      this.message = "";
      ui.message.hidden = true;
    }
    this.updateHud();
  }

  draw(timestamp) {
    const time = timestamp / 1000;
    context.clearRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
    context.fillStyle = "#10241d";
    context.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    for (let y = 0; y < GRID_SIZE; y += 1) {
      for (let x = 0; x < GRID_SIZE; x += 1) {
        const px = x * CELL_SIZE;
        const py = y * CELL_SIZE;
        if (this.maze.grid[y][x] === 1) {
          context.fillStyle = "#244337";
          context.fillRect(px, py, CELL_SIZE, CELL_SIZE);
          context.strokeStyle = "#315746";
          context.lineWidth = 1;
          context.strokeRect(px + 2.5, py + 2.5, CELL_SIZE - 5, CELL_SIZE - 5);
          context.fillStyle = "#355c49";
          context.fillRect(px + 5, py + 5, 3, 3);
        } else {
          context.fillStyle = "#132b23";
          context.fillRect(px, py, CELL_SIZE, CELL_SIZE);
          context.strokeStyle = "#1d392e";
          context.lineWidth = 1;
          context.strokeRect(px + 0.5, py + 0.5, CELL_SIZE - 1, CELL_SIZE - 1);
        }
      }
    }

    this.drawExit(time);
    for (const coin of this.coins) this.drawCoin(coin, time);
    for (const key of this.activeKeys) this.drawKey(key, time);
    if (this.showPath) this.drawPath();
    this.drawCharacter(this.player, "#58cfc0", "#d7fff1", 13, time, 0);
    this.drawCharacter(this.enemy, "#ed705b", "#ffe1d8", 13, time, Math.PI);
  }

  drawExit(time) {
    const { x, y } = this.maze.exit;
    const px = x * CELL_SIZE;
    const py = y * CELL_SIZE;
    const unlocked = this.collectedKeys.size >= this.maze.requiredKeys;
    context.fillStyle = unlocked ? "#3d895f" : "#365e4d";
    context.fillRect(px + 8, py + 7, 24, 28);
    context.strokeStyle = unlocked ? "#8de5a0" : "#83aa86";
    context.lineWidth = 2;
    context.strokeRect(px + 8.5, py + 7.5, 23, 27);
    context.beginPath();
    context.arc(px + 20, py + 16, 6, Math.PI, 0);
    context.stroke();
    context.fillStyle = unlocked ? "#c5ef63" : "#d2c986";
    context.beginPath();
    context.arc(px + 26, py + 23, 2, 0, Math.PI * 2);
    context.fill();
    if (unlocked && this.state === "PLAYING") {
      context.globalAlpha = 0.16 + Math.sin(time * 4) * 0.05;
      context.fillStyle = "#c5ef63";
      context.fillRect(px + 4, py + 3, 32, 34);
      context.globalAlpha = 1;
    }
  }

  drawCoin(id, time) {
    const [x, y] = id.split(",").map(Number);
    const centerX = x * CELL_SIZE + CELL_SIZE / 2;
    const centerY = y * CELL_SIZE + CELL_SIZE / 2 + Math.sin(time * 3 + x) * 1.5;
    context.fillStyle = "#b7832d";
    context.beginPath();
    context.ellipse(centerX, centerY, 8, 9, 0, 0, Math.PI * 2);
    context.fill();
    context.strokeStyle = "#ffe08a";
    context.lineWidth = 2;
    context.beginPath();
    context.ellipse(centerX, centerY, 5, 6, 0, 0, Math.PI * 2);
    context.stroke();
  }

  drawKey(id, time) {
    const [x, y] = id.split(",").map(Number);
    const centerX = x * CELL_SIZE + CELL_SIZE / 2;
    const centerY = y * CELL_SIZE + CELL_SIZE / 2 + Math.sin(time * 2.5 + x * y) * 1.5;
    context.save();
    context.translate(centerX, centerY);
    context.rotate(-0.32);
    context.strokeStyle = "#f5cf63";
    context.fillStyle = "#f5cf63";
    context.lineWidth = 3;
    context.beginPath();
    context.arc(-6, 0, 5, 0, Math.PI * 2);
    context.stroke();
    context.fillRect(-1, -1.5, 15, 3);
    context.fillRect(8, 0, 2.5, 5);
    context.fillRect(13, 0, 2.5, 4);
    context.restore();
  }

  drawPath() {
    if (this.path.length < 2) return;
    context.save();
    context.strokeStyle = "#d8ff7a";
    context.fillStyle = "#d8ff7a";
    context.globalAlpha = 0.75;
    context.lineWidth = 3;
    context.setLineDash([5, 5]);
    context.beginPath();
    this.path.forEach((point, index) => {
      const x = point.x * CELL_SIZE + CELL_SIZE / 2;
      const y = point.y * CELL_SIZE + CELL_SIZE / 2;
      if (index === 0) context.moveTo(x, y);
      else context.lineTo(x, y);
    });
    context.stroke();
    context.setLineDash([]);
    for (let index = 1; index < this.path.length - 1; index += 1) {
      const point = this.path[index];
      context.beginPath();
      context.arc(point.x * CELL_SIZE + CELL_SIZE / 2, point.y * CELL_SIZE + CELL_SIZE / 2, 2.5, 0, Math.PI * 2);
      context.fill();
    }
    context.restore();
  }

  drawCharacter(point, color, highlight, radius, time, eyeOffset) {
    const centerX = point.x * CELL_SIZE + CELL_SIZE / 2;
    const centerY = point.y * CELL_SIZE + CELL_SIZE / 2;
    context.fillStyle = `${color}30`;
    context.beginPath();
    context.arc(centerX, centerY, radius + 5 + Math.sin(time * 3) * 0.5, 0, Math.PI * 2);
    context.fill();
    context.fillStyle = color;
    context.beginPath();
    context.arc(centerX, centerY, radius, 0, Math.PI * 2);
    context.fill();
    context.fillStyle = highlight;
    context.beginPath();
    context.arc(centerX - 3, centerY - 4, 3, 0, Math.PI * 2);
    context.fill();
    context.fillStyle = "#10241d";
    context.beginPath();
    context.arc(centerX + eyeOffset, centerY - 1, 1.7, 0, Math.PI * 2);
    context.fill();
  }
}

const game = new MazeGame();