import math
import sys

import pygame

from astar import AStarPathfinder
from enemy import Enemy
from maze import Maze
from player import Player
from settings import (
    ASSET_DIR,
    LEVELS,
    MAZE_OFFSET_X,
    MAZE_OFFSET_Y,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    TILE_SIZE,
)


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("AI Maze Escape")
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()
        self.running = True
        self.state = "MENU"
        self.current_level = 1
        self.score = 0
        self.health = 3
        self.show_ai_path = False
        self.message = ""
        self.message_timer = 0.0
        self.level_time_left = 0.0
        self.final_score = 0
        self.level_reached = 1

        self.font_title = pygame.font.SysFont("arial", 42, bold=True)
        self.font_big = pygame.font.SysFont("arial", 30, bold=True)
        self.font_medium = pygame.font.SysFont("arial", 22, bold=True)
        self.font_small = pygame.font.SysFont("arial", 18)
        self.font_tiny = pygame.font.SysFont("arial", 16)

        self.maze = None
        self.player = None
        self.enemy = None
        self.pathfinder = AStarPathfinder()
        self.sound_enabled = True
        self.sounds = {}
        self._load_sounds()

    def _load_sounds(self):
        try:
            pygame.mixer.init()
            self.sounds["coin"] = pygame.mixer.Sound("assets/coin.wav") if pygame.mixer.get_init() else None
            self.sounds["key"] = pygame.mixer.Sound("assets/key.wav") if pygame.mixer.get_init() else None
            self.sounds["hit"] = pygame.mixer.Sound("assets/hit.wav") if pygame.mixer.get_init() else None
            self.sounds["win"] = pygame.mixer.Sound("assets/win.wav") if pygame.mixer.get_init() else None
            self.sounds["gameover"] = pygame.mixer.Sound("assets/gameover.wav") if pygame.mixer.get_init() else None
        except Exception:
            self.sound_enabled = False
            self.sounds = {}

    def play_sound(self, name):
        if not self.sound_enabled:
            return
        sound = self.sounds.get(name)
        if sound is not None:
            try:
                sound.play()
            except Exception:
                pass

    def start_game(self):
        self.score = 0
        self.health = 3
        self.level_reached = 1
        self.current_level = 1
        self.load_level(self.current_level)
        self.state = "PLAYING"

    def load_level(self, level_num):
        if 1 <= level_num <= len(LEVELS):
            self.current_level = level_num
            self.level_reached = level_num
            data = LEVELS[level_num - 1]
            self.maze = Maze(data)
            self.player = Player(self.maze.player_start)
            self.player.health = self.health
            self.enemy = Enemy(self.maze.enemy_start, data["enemy_speed"])
            self.level_time_left = self.maze.time_limit
            self.message = f"Level {level_num}: {self.maze.name}"
            self.message_timer = 2.0
            self.enemy.recalculate_path(self.maze, self.player.pos)
            self.show_ai_path = False

    def _attempt_move(self, dx, dy):
        if self.state != "PLAYING":
            return
        if self.player.move(dx, dy, self.maze):
            self._check_collectible()
            if self.player.pos == self.maze.exit_pos and self.player.keys_collected >= self.maze.required_keys:
                self._check_exit()
                return
            self.enemy.recalculate_path(self.maze, self.player.pos)
            self._update_ai_status()

    def _check_collectible(self):
        pos = self.player.pos
        if pos in self.maze.collectibles:
            kind = self.maze.collectibles.pop(pos)
            if kind == "coin":
                self.score += 10
                self.play_sound("coin")
                self.message = "Coin collected! +10"
            else:
                self.score += 20
                self.player.keys_collected += 1
                self.play_sound("key")
                self.message = "Key collected! +20"
            self.message_timer = 1.5
            self.player.score = self.score

    def _hit_enemy(self):
        if self.state != "PLAYING":
            return
        if self.message_timer > 0:
            return
        self.health -= 1
        self.play_sound("hit")
        self.player.reset_to_start(self.maze.player_start)
        self.enemy.pos = self.maze.enemy_start
        self.enemy.path = []
        self.message = "Enemy caught you!"
        self.message_timer = 1.5

        if self.health <= 0:
            self.final_score = self.score
            self.state = "GAME_OVER"

    def _check_exit(self):
        if self.state != "PLAYING":
            return

        if self.player.pos == self.maze.exit_pos:
            if self.player.keys_collected >= self.maze.required_keys:
                level_bonus = 100 + max(0, int(self.level_time_left)) * 5
                self.score += level_bonus
                self.final_score = self.score
                self.enemy.path = []
                self.enemy.status = "WAITING"
                self.play_sound("win")
                self.message = f"Level complete! +{level_bonus}"
                self.message_timer = 2.0
                self.level_time_left = max(0, self.level_time_left)

                if self.current_level >= len(LEVELS):
                    self.state = "WIN"
                else:
                    self.state = "LEVEL_COMPLETE"
                return

            self.message = "Collect all required keys first!"
            self.message_timer = 1.8

    def _advance_to_next_level(self):
        if self.current_level < len(LEVELS):
            self.current_level += 1
            self.level_reached = self.current_level
            self.load_level(self.current_level)
            self.state = "PLAYING"
        else:
            self.state = "WIN"

    def _update_ai_status(self):
        if self.enemy and self.enemy.stats:
            stats = self.enemy.stats
            self.enemy.stats["g_cost"] = stats.get("g_cost", 0)
            self.enemy.stats["h_cost"] = stats.get("h_cost", 0)
            self.enemy.stats["f_cost"] = stats.get("f_cost", 0)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self._handle_button_click(event.pos)
                continue

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                    return

                if self.state == "PLAYING":
                    if event.key in (pygame.K_w, pygame.K_UP):
                        self._attempt_move(0, -1)
                    elif event.key in (pygame.K_s, pygame.K_DOWN):
                        self._attempt_move(0, 1)
                    elif event.key in (pygame.K_a, pygame.K_LEFT):
                        self._attempt_move(-1, 0)
                    elif event.key in (pygame.K_d, pygame.K_RIGHT):
                        self._attempt_move(1, 0)
                    elif event.key == pygame.K_p:
                        self.show_ai_path = not self.show_ai_path
                    elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        self.start_game()
                    continue

                if self.state == "GAME_OVER":
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        self.start_game()
                    continue

                if self.state == "WIN":
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        self.start_game()
                    continue

    def _handle_button_click(self, pos):
        if self.state == "MENU":
            for label, rect, action in self._main_menu_buttons():
                if rect.collidepoint(pos):
                    if action == "start":
                        self.start_game()
                    elif action == "exit":
                        self.running = False
        elif self.state == "GAME_OVER":
            for label, rect, action in self._game_over_buttons():
                if rect.collidepoint(pos):
                    if action == "play_again":
                        self.start_game()
                    elif action == "main_menu":
                        self.state = "MENU"
        elif self.state == "LEVEL_COMPLETE":
            for label, rect, action in self._level_complete_buttons():
                if rect.collidepoint(pos):
                    if action == "next_level":
                        self._advance_to_next_level()
                    elif action == "main_menu":
                        self.state = "MENU"
        elif self.state == "WIN":
            for label, rect, action in self._win_buttons():
                if rect.collidepoint(pos):
                    if action == "play_again":
                        self.start_game()

    def _main_menu_buttons(self):
        buttons = []
        start_rect = pygame.Rect(SCREEN_WIDTH // 2 - 120, 360, 240, 60)
        exit_rect = pygame.Rect(SCREEN_WIDTH // 2 - 120, 460, 240, 60)
        buttons.append(("START", start_rect, "start"))
        buttons.append(("EXIT", exit_rect, "exit"))
        return buttons

    def _game_over_buttons(self):
        play_rect = pygame.Rect(SCREEN_WIDTH // 2 - 150, 520, 300, 58)
        menu_rect = pygame.Rect(SCREEN_WIDTH // 2 - 150, 590, 300, 58)
        return [("PLAY AGAIN", play_rect, "play_again"), ("MAIN MENU", menu_rect, "main_menu")]

    def _level_complete_buttons(self):
        next_rect = pygame.Rect(SCREEN_WIDTH // 2 - 150, 520, 300, 58)
        menu_rect = pygame.Rect(SCREEN_WIDTH // 2 - 150, 590, 300, 58)
        return [("NEXT LEVEL", next_rect, "next_level"), ("MAIN MENU", menu_rect, "main_menu")]

    def _win_buttons(self):
        play_rect = pygame.Rect(SCREEN_WIDTH // 2 - 150, 520, 300, 58)
        return [("PLAY AGAIN", play_rect, "play_again")]

    def update(self, dt):
        if self.state != "PLAYING":
            return

        if self.maze is None or self.player is None or self.enemy is None:
            return

        # Highest priority: a valid exit success MUST freeze the game before timer or enemy logic runs.
        if self.player.pos == self.maze.exit_pos and self.player.keys_collected >= self.maze.required_keys:
            self._check_exit()
            return

        self.level_time_left -= dt

        if self.level_time_left <= 0:
            self.final_score = self.score
            self.state = "GAME_OVER"
            self.message = "TIME UP!"
            self.play_sound("gameover")
            return

        if self.message_timer > 0:
            self.message_timer -= dt
        else:
            self.message = ""

        # Enemy AI and collision are only processed while in PLAYING state.
        self.enemy.update(dt, self.maze, self.player.pos)
        self._update_ai_status()

        if self.player.pos == self.enemy.pos:
            self._hit_enemy()
            if self.state != "PLAYING":
                return

        if self.player.pos == self.maze.exit_pos and self.player.keys_collected >= self.maze.required_keys:
            self._check_exit()

    def draw(self):
        self.screen.fill((7, 10, 14))

        if self.state == "MENU":
            self._draw_menu()
        elif self.state == "HOW_TO_PLAY":
            self._draw_how_to_play()
        elif self.state == "AI_INFO":
            self._draw_ai_info()
        elif self.state == "PLAYING":
            self._draw_game()
        elif self.state == "GAME_OVER":
            self._draw_game_over()
        elif self.state == "LEVEL_COMPLETE":
            self._draw_level_complete()
        elif self.state == "WIN":
            self._draw_win()
        else:
            self._draw_game()

        pygame.display.flip()

    def _draw_menu(self):
        self.screen.fill((10, 14, 20))
        self._render_centered_text("AI MAZE ESCAPE", self.font_title, (255, 255, 255), 120)
        self._render_centered_text("Find the keys and escape!", self.font_medium, (120, 210, 255), 180)

        for label, rect, action in self._main_menu_buttons():
            color = (26, 85, 120) if action == "start" else (90, 50, 50)
            pygame.draw.rect(self.screen, color, rect, border_radius=10)
            pygame.draw.rect(self.screen, (138, 202, 255), rect, 2, border_radius=10)
            text = self.font_medium.render(label, True, (255, 255, 255))
            self.screen.blit(text, (rect.centerx - text.get_width() // 2, rect.centery - text.get_height() // 2))

    def _draw_how_to_play(self):
        self.screen.fill((15, 20, 26))
        self._render_centered_text("HOW TO PLAY", self.font_title, (255, 255, 255), 60)
        text_lines = [
            "W / A / S / D   Move Player",
            "Collect keys and coins.",
            "Avoid the intelligent enemy.",
            "The enemy uses A* pathfinding",
            "to find the best route to you.",
            "Collect the required keys",
            "and reach the exit.",
            "",
            "Press ESC to return.",
        ]
        y = 130
        for line in text_lines:
            color = (180, 210, 255) if "Press ESC" not in line else (255, 204, 102)
            self._render_centered_text(line, self.font_medium, color, y)
            y += 45

    def _draw_ai_info(self):
        self.screen.fill((15, 20, 26))
        self._render_centered_text("HOW A* WORKS", self.font_title, (255, 255, 255), 50)
        lines = [
            "A* is a pathfinding algorithm.",
            "It combines:",
            "G(n) = Cost from start node",
            "H(n) = Estimated cost to goal",
            "F(n) = G(n) + H(n)",
            "",
            "The enemy uses A* to find",
            "an efficient path toward",
            "the player while avoiding walls.",
            "",
            "Enemy → Path → Player",
        ]
        y = 120
        for line in lines:
            self._render_centered_text(line, self.font_medium, (220, 230, 255), y)
            y += 40

        # small visual example
        start_x = SCREEN_WIDTH // 2 - 130
        player_x = SCREEN_WIDTH // 2 + 70
        pygame.draw.circle(self.screen, (255, 98, 98), (start_x, 430), 18)
        pygame.draw.circle(self.screen, (90, 180, 255), (player_x, 430), 18)
        pygame.draw.line(self.screen, (255, 220, 120), (start_x + 18, 430), (player_x - 18, 430), 4)
        self._render_centered_text("Enemy", self.font_small, (255, 255, 255), 470)
        self._render_centered_text("Player", self.font_small, (255, 255, 255), 470)

    def _draw_game(self):
        if self.maze is None:
            return

        self.screen.fill((11, 15, 19))
        self._draw_hud()
        self.maze.draw(
            self.screen,
            TILE_SIZE,
            MAZE_OFFSET_X,
            MAZE_OFFSET_Y,
            show_path=self.show_ai_path,
            path=self.enemy.path if self.show_ai_path else [],
            player_pos=self.player.pos,
            enemy_pos=self.enemy.pos,
        )
        self._draw_ai_panel()
        if self.message:
            msg = self.font_medium.render(self.message, True, (255, 255, 255))
            rect = msg.get_rect(center=(SCREEN_WIDTH // 2, 38))
            pygame.draw.rect(self.screen, (28, 35, 44), rect.inflate(26, 16), border_radius=10)
            self.screen.blit(msg, rect)

        # Toggle button for AI path
        toggle_rect = pygame.Rect(825, 160, 180, 38)
        color = (45, 167, 120) if self.show_ai_path else (88, 88, 88)
        pygame.draw.rect(self.screen, color, toggle_rect, border_radius=12)
        label = self.font_small.render("SHOW AI PATH" if self.show_ai_path else "SHOW AI PATH", True, (255, 255, 255))
        self.screen.blit(label, (toggle_rect.centerx - label.get_width() // 2, toggle_rect.centery - label.get_height() // 2))

    def _draw_hud(self):
        hud_y = 20
        info = [
            f"LEVEL: {self.current_level}",
            f"SCORE: {self.score:04d}",
            f"HEALTH: {'♥' * self.health}{'♡' * (3 - self.health)}",
            f"KEYS: {self.player.keys_collected}/{self.maze.required_keys}",
            f"TIME: {max(0, int(self.level_time_left))}",
        ]
        x = 30
        for text in info:
            label = self.font_small.render(text, True, (240, 245, 255))
            self.screen.blit(label, (x, hud_y))
            hud_y += 30

    def _draw_ai_panel(self):
        panel_rect = pygame.Rect(820, 220, 240, 200)
        pygame.draw.rect(self.screen, (18, 25, 33), panel_rect, border_radius=12)
        pygame.draw.rect(self.screen, (114, 164, 255), panel_rect, 2, border_radius=12)

        stats = self.enemy.stats if self.enemy else {"g_cost": 0, "h_cost": 0, "f_cost": 0, "path_length": 0, "nodes_explored": 0}
        lines = [
            "AI STATUS",
            "Algorithm: A*",
            f"G Cost: {stats.get('g_cost', 0)}",
            f"H Cost: {stats.get('h_cost', 0)}",
            f"F Cost: {stats.get('f_cost', 0)}",
            f"Path Length: {stats.get('path_length', 0)}",
            f"Nodes Explored: {stats.get('nodes_explored', 0)}",
            f"Enemy Status: {self.enemy.status if self.enemy else 'READY'}",
        ]
        y = 245
        for line in lines:
            label = self.font_tiny.render(line, True, (230, 240, 255))
            self.screen.blit(label, (835, y))
            y += 20

    def _render_centered_text(self, text, font, color, y):
        rendered = font.render(text, True, color)
        x = (SCREEN_WIDTH - rendered.get_width()) // 2
        self.screen.blit(rendered, (x, y))

    def _draw_game_over(self):
        self.screen.fill((18, 10, 14))
        self._render_centered_text("GAME OVER", self.font_title, (255, 110, 110), 160)
        self._render_centered_text(f"Your Score: {self.score}", self.font_medium, (255, 255, 255), 225)
        self._render_centered_text(f"Level Reached: {self.level_reached}", self.font_medium, (255, 255, 255), 260)
        for label, rect, action in self._game_over_buttons():
            color = (175, 70, 70) if action == "play_again" else (52, 64, 72)
            pygame.draw.rect(self.screen, color, rect, border_radius=12)
            pygame.draw.rect(self.screen, (255, 255, 255), rect, 2, border_radius=12)
            text = self.font_medium.render(label, True, (255, 255, 255))
            self.screen.blit(text, (rect.centerx - text.get_width() // 2, rect.centery - text.get_height() // 2))

    def _draw_level_complete(self):
        self.screen.fill((12, 20, 18))
        self._render_centered_text("LEVEL COMPLETE!", self.font_title, (140, 255, 200), 150)
        self._render_centered_text(f"Level: {self.current_level}", self.font_medium, (255, 255, 255), 225)
        self._render_centered_text(f"Score: {self.score}", self.font_medium, (255, 255, 255), 260)
        self._render_centered_text(f"Time Remaining: {max(0, int(self.level_time_left))}", self.font_medium, (255, 255, 255), 295)
        for label, rect, action in self._level_complete_buttons():
            color = (40, 160, 110) if action == "next_level" else (52, 64, 72)
            pygame.draw.rect(self.screen, color, rect, border_radius=12)
            pygame.draw.rect(self.screen, (255, 255, 255), rect, 2, border_radius=12)
            text = self.font_medium.render(label, True, (255, 255, 255))
            self.screen.blit(text, (rect.centerx - text.get_width() // 2, rect.centery - text.get_height() // 2))

    def _draw_win(self):
        self.screen.fill((8, 15, 22))
        self._render_centered_text("================================", self.font_small, (255, 255, 255), 60)
        self._render_centered_text("YOU ESCAPED!", self.font_title, (255, 215, 120), 120)
        self._render_centered_text("AI MAZE MASTER", self.font_medium, (180, 220, 255), 190)
        self._render_centered_text(f"Final Score: {self.score}", self.font_medium, (255, 255, 255), 240)
        self._render_centered_text("A* Pathfinding successfully", self.font_small, (230, 230, 255), 300)
        self._render_centered_text("helped the enemy navigate", self.font_small, (230, 230, 255), 330)
        self._render_centered_text("the maze.", self.font_small, (230, 230, 255), 360)
        rect = pygame.Rect(SCREEN_WIDTH // 2 - 160, 430, 320, 60)
        pygame.draw.rect(self.screen, (78, 135, 255), rect, border_radius=14)
        text = self.font_medium.render("PLAY AGAIN", True, (255, 255, 255))
        self.screen.blit(text, (rect.centerx - text.get_width() // 2, rect.centery - text.get_height() // 2))

    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            self.handle_events()
            self.update(dt)
            self.draw()
        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    Game().run()
