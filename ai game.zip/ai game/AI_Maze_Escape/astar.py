import heapq
from math import inf


class AStarPathfinder:
    def __init__(self):
        self.last_nodes_explored = 0
        self.last_path = []
        self.last_g_cost = 0
        self.last_h_cost = 0
        self.last_f_cost = 0

    @staticmethod
    def manhattan(start, goal):
        return abs(start[0] - goal[0]) + abs(start[1] - goal[1])

    @staticmethod
    def neighbors(grid, pos):
        rows = len(grid)
        cols = len(grid[0]) if rows else 0
        r, c = pos
        directions = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        result = []

        for dr, dc in directions:
            nr = r + dr
            nc = c + dc
            if 0 <= nr < rows and 0 <= nc < cols:
                if grid[nr][nc] != 1:
                    result.append((nr, nc))
        return result

    def find_path(self, grid, start, goal):
        if start == goal:
            self.last_path = [start]
            self.last_nodes_explored = 1
            self.last_g_cost = 0
            self.last_h_cost = 0
            self.last_f_cost = 0
            return [start]

        open_heap = []
        heapq.heappush(open_heap, (0, self.manhattan(start, goal), start))

        came_from = {}
        g_costs = {start: 0}
        explored = 0

        while open_heap:
            _, _, current = heapq.heappop(open_heap)

            if current == goal:
                path = self._reconstruct_path(came_from, start, goal)
                self.last_path = path
                self.last_nodes_explored = explored
                self.last_g_cost = g_costs.get(goal, 0)
                self.last_h_cost = self.manhattan(goal, goal)
                self.last_f_cost = self.last_g_cost + self.last_h_cost
                return path

            for neighbor in self.neighbors(grid, current):
                tentative_g = g_costs[current] + 1
                if neighbor not in g_costs or tentative_g < g_costs[neighbor]:
                    came_from[neighbor] = current
                    g_costs[neighbor] = tentative_g
                    h_cost = self.manhattan(neighbor, goal)
                    f_cost = tentative_g + h_cost
                    heapq.heappush(open_heap, (f_cost, h_cost, neighbor))
                    explored += 1

        self.last_path = []
        self.last_nodes_explored = explored
        self.last_g_cost = 0
        self.last_h_cost = 0
        self.last_f_cost = 0
        return []

    def _reconstruct_path(self, came_from, start, goal):
        path = []
        current = goal

        while current != start:
            path.append(current)
            if current not in came_from:
                return []
            current = came_from[current]

        path.append(start)
        path.reverse()
        return path


def a_star_path(grid, start, goal):
    finder = AStarPathfinder()
    path = finder.find_path(grid, start, goal)
    return path, finder.last_nodes_explored, finder.last_g_cost, finder.last_h_cost, finder.last_f_cost
