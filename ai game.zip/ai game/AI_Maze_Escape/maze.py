from collections import deque
import random

import pygame


def generate_key_positions(maze, number_of_keys):
    reachable = set()
    pending = deque([maze.player_start])
    while pending:
        pos = pending.popleft()
        if pos in reachable or not maze.is_walkable(pos):
            continue
        reachable.add(pos)
        row, col = pos
        pending.extend(((row + 1, col), (row - 1, col), (row, col + 1), (row, col - 1)))

    reserved = {maze.player_start, maze.enemy_start, maze.exit_pos}
    candidates = sorted(reachable - reserved - set(maze.collectibles))
    if len(candidates) < number_of_keys:
        raise ValueError(f"Not enough reachable spaces for keys in {maze.name}")

    distances = {}
    for start in candidates:
        distance_map = {start: 0}
        pending = deque([start])
        while pending:
            pos = pending.popleft()
            row, col = pos
            for neighbor in ((row + 1, col), (row - 1, col), (row, col + 1), (row, col - 1)):
                if neighbor in reachable and neighbor not in distance_map:
                    distance_map[neighbor] = distance_map[pos] + 1
                    pending.append(neighbor)
        distances[start] = distance_map

    def creates_straight_line(candidate, selected):
        for first_index, first in enumerate(selected):
            for second in selected[first_index + 1:]:
                first_row, first_col = first
                second_row, second_col = second
                candidate_row, candidate_col = candidate
                if (second_row - first_row) * (candidate_col - first_col) == (second_col - first_col) * (candidate_row - first_row):
                    return True
        return False

    for minimum_spacing in (6, 5, 4, 3, 2):
        for _ in range(100):
            selected = [random.choice(candidates)]
            while len(selected) < number_of_keys:
                options = []
                for candidate in candidates:
                    if any(candidate[0] == pos[0] or candidate[1] == pos[1] for pos in selected):
                        continue
                    if creates_straight_line(candidate, selected):
                        continue
                    spacing = min(distances[candidate][pos] for pos in selected)
                    if spacing >= minimum_spacing:
                        options.append((candidate, spacing))

                if not options:
                    break

                greatest_spacing = max(spacing for _, spacing in options)
                farthest = [pos for pos, spacing in options if spacing == greatest_spacing]
                selected.append(random.choice(farthest))

            if len(selected) == number_of_keys:
                return selected

    raise ValueError(f"Cannot spread {number_of_keys} keys across {maze.name}")


class Maze:
    def __init__(self, level_data):
        self.name = level_data["name"]
        self.required_keys = level_data["required_keys"]
        self.time_limit = level_data["time_limit"]
        self.enemy_speed = level_data["enemy_speed"]
        self.grid = self._parse_grid(level_data["grid"])
        self.key_positions = []
        self.collectibles = {}
        self.player_start = None
        self.enemy_start = None
        self.exit_pos = None
        self._scan_level()

    def _parse_grid(self, rows):
        return [[int(ch) for ch in row] for row in rows]

    def _scan_level(self):
        for row_index, row in enumerate(self.grid):
            for col_index, value in enumerate(row):
                if value == 2:
                    self.player_start = (row_index, col_index)
                elif value == 3:
                    self.enemy_start = (row_index, col_index)
                elif value == 4:
                    self.exit_pos = (row_index, col_index)
                elif value == 5:
                    self.collectibles[(row_index, col_index)] = "coin"

        self.key_positions = generate_key_positions(self, self.required_keys)
        for pos in self.key_positions:
            self.collectibles[pos] = "key"

    def is_walkable(self, pos):
        if pos is None:
            return False
        row, col = pos
        if row < 0 or col < 0 or row >= len(self.grid) or col >= len(self.grid[0]):
            return False
        return self.grid[row][col] != 1

    def draw(self, screen, cell_size, offset_x, offset_y, show_path=False, path=None, player_pos=None, enemy_pos=None):
        rows = len(self.grid)
        cols = len(self.grid[0])

        for row in range(rows):
            for col in range(cols):
                value = self.grid[row][col]
                x = offset_x + col * cell_size
                y = offset_y + row * cell_size

                if value == 1:
                    pygame.draw.rect(screen, (40, 52, 66), (x, y, cell_size, cell_size))
                    pygame.draw.rect(screen, (20, 30, 38), (x + 2, y + 2, cell_size - 4, cell_size - 4), 1)
                else:
                    pygame.draw.rect(screen, (26, 32, 41), (x, y, cell_size, cell_size))

                if (row, col) == self.exit_pos:
                    pygame.draw.rect(screen, (38, 130, 95), (x + 5, y + 5, cell_size - 10, cell_size - 10), border_radius=8)
                    pygame.draw.rect(screen, (150, 255, 175), (x + 10, y + 10, cell_size - 20, cell_size - 20), 2, border_radius=8)

                if (row, col) in self.collectibles:
                    kind = self.collectibles[(row, col)]
                    cx = x + cell_size // 2
                    cy = y + cell_size // 2
                    radius = cell_size // 3
                    if kind == "key":
                        pygame.draw.circle(screen, (255, 215, 70), (cx - 5, cy), 6, 3)
                        pygame.draw.line(screen, (255, 215, 70), (cx, cy), (cx + 10, cy), 4)
                        pygame.draw.line(screen, (255, 215, 70), (cx + 6, cy), (cx + 6, cy + 5), 3)
                        pygame.draw.line(screen, (255, 215, 70), (cx + 10, cy), (cx + 10, cy + 4), 3)
                    else:
                        pygame.draw.circle(screen, (255, 215, 70), (cx, cy), radius)
                        pygame.draw.circle(screen, (255, 255, 255), (cx - 4, cy - 4), 4)

                if show_path and path:
                    if (row, col) in path:
                        pygame.draw.rect(screen, (255, 245, 150), (x + 6, y + 6, cell_size - 12, cell_size - 12), border_radius=3)

        if player_pos:
            px = offset_x + player_pos[1] * cell_size + cell_size // 2
            py = offset_y + player_pos[0] * cell_size + cell_size // 2
            pygame.draw.circle(screen, (90, 180, 255), (px, py), cell_size // 2 - 6)

        if enemy_pos:
            ex = offset_x + enemy_pos[1] * cell_size + cell_size // 2
            ey = offset_y + enemy_pos[0] * cell_size + cell_size // 2
            pygame.draw.circle(screen, (255, 90, 90), (ex, ey), cell_size // 2 - 6)

        pygame.draw.rect(screen, (10, 10, 10), (offset_x - 8, offset_y - 8, cols * cell_size + 16, rows * cell_size + 16), 2)
