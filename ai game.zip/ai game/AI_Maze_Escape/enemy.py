import pygame

from astar import AStarPathfinder


class Enemy:
    def __init__(self, start_pos, speed):
        self.pos = start_pos
        self.path = []
        self.speed = speed
        self.recalc_timer = 0.0
        self.move_cooldown = 0.0
        self.status = "PATROL"
        self.stats = {"g_cost": 0, "h_cost": 0, "f_cost": 0, "path_length": 0, "nodes_explored": 0}

    def recalculate_path(self, maze, player_pos):
        pathfinder = AStarPathfinder()
        grid = maze.grid
        start = self.pos
        goal = player_pos
        path = pathfinder.find_path(grid, start, goal)

        if path and len(path) > 1:
            self.path = path
            self.status = "CHASING"
        else:
            self.path = []
            self.status = "SEARCHING"

        self.stats = {
            "g_cost": pathfinder.last_g_cost,
            "h_cost": pathfinder.last_h_cost,
            "f_cost": pathfinder.last_f_cost,
            "path_length": len(path) - 1 if path else 0,
            "nodes_explored": pathfinder.last_nodes_explored,
        }

    def update(self, dt, maze, player_pos):
        self.recalc_timer += dt
        self.move_cooldown -= dt

        if self.recalc_timer >= 0.7:
            self.recalculate_path(maze, player_pos)
            self.recalc_timer = 0.0

        if not self.path or len(self.path) <= 1:
            self.status = "SEARCHING"
            return

        if self.move_cooldown <= 0:
            next_step = self.path[1]
            if maze.is_walkable(next_step):
                self.pos = next_step
                self.path = self.path[1:]
            else:
                self.path = []
                self.status = "SEARCHING"
            self.move_cooldown = self.speed

    def draw(self, screen, cell_size, offset_x, offset_y, color=(255, 90, 90)):
        ex = offset_x + self.pos[1] * cell_size + cell_size // 2
        ey = offset_y + self.pos[0] * cell_size + cell_size // 2
        radius = cell_size // 2 - 5
        pygame.draw.circle(screen, color, (ex, ey), radius)
        pygame.draw.circle(screen, (255, 255, 255), (ex - 4, ey - 4), 4)
