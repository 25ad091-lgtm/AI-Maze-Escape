# AI MAZE ESCAPE

AI Maze Escape is a beginner-friendly 2D AI game made with Python and Pygame. The player must collect all required keys, avoid the enemy, and reach the exit.

## Game idea

The player moves through a maze. The enemy uses the A* Search Algorithm to find the best path toward the player while avoiding walls.

## AI algorithm

The enemy uses A* pathfinding:

- G cost: distance from the start node
- H cost: estimated distance to the goal
- F cost: G + H
- Heuristic used: Manhattan distance

This makes the enemy behave intelligently.

## Controls

- W / A / S / D or Arrow Keys: Move
- P: Show or hide the enemy path
- ESC: Quit

## Installation

```bash
pip install -r requirements.txt
```

## Run the game

```bash
python main.py
```

## Features

- 5 levels with increasing difficulty
- Score, health, timer, and level display
- Key collection system
- AI enemy using A* search
- Main menu with Play, How to Play, AI Information, and Quit
