import heapq
import random
import sys

import pygame


WIDTH = 900
HEIGHT = 700
GRID_SIZE = 15
TILE_SIZE = 38
OFFSET_X = 80
OFFSET_Y = 60

LEVELS = [
    {
        "name": "Level 1",
        "required_keys": 3,
        "time_limit": 70,
        "enemy_speed": 1.0,
        "grid": [
            "111111111111111",
            "100000000000001",
            "101111011111101",
            "100100010001001",
            "101101110101101",
            "100001000100001",
            "111101011101111",
            "100001000001001",
            "101111011101101",
            "100000010000001",
            "101111010111101",
            "100000010000001",
            "102000030000041",
            "100000500000001",
            "111111111111111",
        ],
    },
    {
        "name": "Level 2",
        "required_keys": 4,
        "time_limit": 60,
        "enemy_speed": 0.9,
        "grid": [
            "111111111111111",
            "100000000000001",
            "101111011111101",
            "100001000010001",
            "101101110110101",
            "100100050100001",
            "111101011101111",
            "100001010000001",
            "101111010111101",
            "100000010000001",
            "101101110110101",
            "100100000010001",
            "102000030000041",
            "100005000000001",
            "111111111111111",
        ],
    },
    {
        "name": "Level 3",
        "required_keys": 5,
        "time_limit": 55,
        "enemy_speed": 0.8,
        "grid": [
            "111111111111111",
            "100000050000001",
            "101111011111101",
            "100001000010001",
            "111101110110111",
            "100000010000001",
            "101111010111101",
            "100100010100001",
            "101101110101101",
            "100000000000001",
            "101111011111101",
            "100010000010001",
            "102000030000041",
            "100005000050001",
            "111111111111111",
        ],
    },
    {
        "name": "Level 4",
        "required_keys": 6,
        "time_limit": 50,
        "enemy_speed": 0.75,
        "grid": [
            "111111111111111",
            "100000500000001",
            "101111011111101",
            "101000010000101",
            "101011110111101",
            "100010000010001",
            "111110111110111",
            "100000010000001",
            "101111010111101",
            "100001000010001",
            "111101110110111",
            "100000050000001",
            "102000030000041",
            "100005000500001",
            "111111111111111",
        ],
    },
    {
        "name": "Level 5",
        "required_keys": 7,
        "time_limit": 45,
        "enemy_speed": 0.7,
        "grid": [
            "111111111111111",
            "100000050000001",
            "101111011111101",
            "100000010000001",
            "111101110110111",
            "100001000010001",
            "101111011111101",
            "100010050010001",
            "101110111011101",
            "100000000000001",
            "111111010111111",
            "100000010000001",
            "102000030000041",
            "100005000500001",
            "111111111111111",
        ],
    },
]


def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def find_path(start, goal, walls):
    if start == goal:
        return [start]

    open_heap = []
    heapq.heappush(open_heap, (0, 0, start))
    came_from = {start: None}
    g_cost = {start: 0}

    while open_heap:
        _, _, current = heapq.heappop(open_heap)
        if current == goal:
            break

        for dx, dy in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            nxt = (current[0] + dx, current[1] + dy)
            if nxt in walls:
                continue
            if nxt[0] < 0 or nxt[1] < 0 or nxt[0] >= GRID_SIZE or nxt[1] >= GRID_SIZE:
                continue

            new_cost = g_cost[current] + 1
            if nxt not in g_cost or new_cost < g_cost[nxt]:
                came_from[nxt] = current
                g_cost[nxt] = new_cost
                heapq.heappush(open_heap, (new_cost + manhattan(nxt, goal), new_cost, nxt))

    if goal not in came_from:
        return []

    path = []
    current = goal
    while current is not None:
        path.append(current)
        current = came_from[current]
    path.reverse()
    return path


def generate_key_positions(maze, number_of_keys):
    walkable = {
        (x, y)
        for y in range(GRID_SIZE)
        for x in range(GRID_SIZE)
        if (x, y) not in maze.walls
    }
    reserved = {maze.player_start, maze.enemy_start, maze.exit_pos}
    reachable = set()
    pending = [maze.player_start]
    while pending:
        pos = pending.pop()
        if pos in reachable or pos not in walkable:
            continue
        reachable.add(pos)
        x, y = pos
        pending.extend(((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)))

    candidates = sorted(reachable - reserved)
    if len(candidates) < number_of_keys:
        raise ValueError(f"Not enough reachable spaces for keys in {maze.name}")

    distances = {}
    for start in candidates:
        distance_map = {start: 0}
        pending = [start]
        while pending:
            pos = pending.pop(0)
            x, y = pos
            for neighbor in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if neighbor in reachable and neighbor not in distance_map:
                    distance_map[neighbor] = distance_map[pos] + 1
                    pending.append(neighbor)
        distances[start] = distance_map

    def creates_straight_line(candidate, selected):
        for first_index, first in enumerate(selected):
            for second in selected[first_index + 1:]:
                first_x, first_y = first
                second_x, second_y = second
                candidate_x, candidate_y = candidate
                if (second_x - first_x) * (candidate_y - first_y) == (second_y - first_y) * (candidate_x - first_x):
                    return True
        return False

    for minimum_spacing in (6, 5, 4, 3, 2):
        for _ in range(100):
            selected = [random.choice(candidates)]
            while len(selected) < number_of_keys:
                options = []
                for candidate in candidates:
                    if any(candidate[0] == pos[0] or candidate[1] == pos[1] for pos in selected):
                        continue
                    if creates_straight_line(candidate, selected):
                        continue
                    spacing = min(distances[candidate][pos] for pos in selected)
                    if spacing >= minimum_spacing:
                        options.append((candidate, spacing))

                if not options:
                    break

                greatest_spacing = max(spacing for _, spacing in options)
                farthest = [pos for pos, spacing in options if spacing == greatest_spacing]
                selected.append(random.choice(farthest))

            if len(selected) == number_of_keys:
                return selected

    raise ValueError(f"Cannot spread {number_of_keys} keys across {maze.name}")


class Maze:
    def __init__(self, level_data):
        self.name = level_data["name"]
        self.required_keys = level_data["required_keys"]
        self.time_limit = level_data["time_limit"]
        self.enemy_speed = level_data["enemy_speed"]
        self.grid = level_data["grid"]
        self.key_positions = []
        self.keys = []
        self.walls = set()
        self.player_start = None
        self.enemy_start = None
        self.exit_pos = None

        for row_index, row in enumerate(self.grid):
            for col_index, ch in enumerate(row):
                if ch == "1":
                    self.walls.add((col_index, row_index))
                elif ch == "2":
                    self.player_start = (col_index, row_index)
                elif ch == "3":
                    self.enemy_start = (col_index, row_index)
                elif ch == "4":
                    self.exit_pos = (col_index, row_index)

        self.key_positions = generate_key_positions(self, self.required_keys)
        self.keys = list(self.key_positions)

    def draw(self, screen, player_pos, enemy_pos, collected_keys):
        for y in range(GRID_SIZE):
            for x in range(GRID_SIZE):
                tile_x = OFFSET_X + x * TILE_SIZE
                tile_y = OFFSET_Y + y * TILE_SIZE
                pos = (x, y)

                if pos in self.walls:
                    pygame.draw.rect(screen, (30, 40, 55), (tile_x, tile_y, TILE_SIZE, TILE_SIZE))
                    pygame.draw.rect(screen, (90, 130, 180), (tile_x + 2, tile_y + 2, TILE_SIZE - 4, TILE_SIZE - 4))
                else:
                    pygame.draw.rect(screen, (18, 24, 32), (tile_x, tile_y, TILE_SIZE, TILE_SIZE), 1)

                if pos == self.exit_pos:
                    pygame.draw.rect(screen, (90, 200, 120), (tile_x + 8, tile_y + 8, TILE_SIZE - 16, TILE_SIZE - 16), border_radius=8)

                if pos in self.keys and pos not in collected_keys:
                    key_center_x = tile_x + TILE_SIZE // 2
                    key_center_y = tile_y + TILE_SIZE // 2
                    pygame.draw.circle(screen, (255, 215, 0), (key_center_x, key_center_y), 8)
                    pygame.draw.rect(screen, (255, 230, 120), (key_center_x - 10, key_center_y - 4, 20, 8), border_radius=3)
                    pygame.draw.rect(screen, (255, 230, 120), (key_center_x + 5, key_center_y - 1, 10, 4), border_radius=2)
                    pygame.draw.circle(screen, (255, 215, 0), (key_center_x + 14, key_center_y + 1), 3)

        px = OFFSET_X + player_pos[0] * TILE_SIZE + TILE_SIZE // 2
        py = OFFSET_Y + player_pos[1] * TILE_SIZE + TILE_SIZE // 2
        pygame.draw.circle(screen, (90, 180, 255), (px, py), 12)

        ex = OFFSET_X + enemy_pos[0] * TILE_SIZE + TILE_SIZE // 2
        ey = OFFSET_Y + enemy_pos[1] * TILE_SIZE + TILE_SIZE // 2
        pygame.draw.circle(screen, (255, 100, 100), (ex, ey), 12)


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("AI MAZE ESCAPE")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.running = True

        self.font_title = pygame.font.SysFont("arial", 38, bold=True)
        self.font_sub = pygame.font.SysFont("arial", 24, bold=True)
        self.font_body = pygame.font.SysFont("arial", 20)
        self.font_small = pygame.font.SysFont("arial", 16)

        self.state = "MENU"
        self.current_level = 1
        self.score = 0
        self.health = 3
        self.level_time = 0
        self.message = ""
        self.message_timer = 0
        self.show_enemy_path = False

        self.maze = None
        self.player_pos = None
        self.enemy_pos = None
        self.collected_keys = set()
        self.key_count = 0
        self.enemy_path = []
        self.enemy_move_timer = 0
        self.enemy_status = "IDLE"

    def start_game(self):
        self.score = 0
        self.health = 3
        self.current_level = 1
        self.load_level(self.current_level)
        self.state = "PLAYING"

    def load_level(self, level_number):
        level_data = LEVELS[level_number - 1]
        self.maze = Maze(level_data)
        self.player_pos = self.maze.player_start
        self.enemy_pos = self.maze.enemy_start
        self.collected_keys = set()
        self.key_count = 0
        self.level_time = self.maze.time_limit
        self.message = f"{self.maze.name}"
        self.message_timer = 2.0
        self.enemy_move_timer = 0
        self.enemy_status = "SEARCHING"
        self.enemy_path = find_path(self.enemy_pos, self.player_pos, self.maze.walls)

    def move_player(self, dx, dy):
        if self.state != "PLAYING":
            return

        next_pos = (self.player_pos[0] + dx, self.player_pos[1] + dy)
        if next_pos in self.maze.walls:
            return

        self.player_pos = next_pos
        self.collect_key_if_needed()
        self.check_exit()

    def collect_key_if_needed(self):
        if self.player_pos in self.maze.key_positions and self.player_pos not in self.collected_keys:
            self.collected_keys.add(self.player_pos)
            self.key_count += 1
            self.score += 20
            self.message = "Key collected! +20"
            self.message_timer = 1.5

    def check_exit(self):
        if self.player_pos == self.maze.exit_pos:
            if self.key_count >= self.maze.required_keys:
                bonus = 100 + int(self.level_time) * 5
                self.score += bonus
                if self.current_level >= len(LEVELS):
                    self.state = "WIN"
                else:
                    self.state = "LEVEL_COMPLETE"
                self.message = f"Level complete! +{bonus}"
                self.message_timer = 2.0
            else:
                self.message = "Collect all required keys first!"
                self.message_timer = 1.5

    def advance_level(self):
        if self.current_level < len(LEVELS):
            self.current_level += 1
            self.load_level(self.current_level)
            self.state = "PLAYING"
        else:
            self.start_game()

    def enemy_step(self):
        if self.state != "PLAYING":
            return

        path = find_path(self.enemy_pos, self.player_pos, self.maze.walls)
        if len(path) >= 2:
            self.enemy_path = path
            self.enemy_pos = path[1]
            self.enemy_status = "CHASING"
        else:
            self.enemy_path = []
            self.enemy_status = "SEARCHING"

    def update(self, dt):
        if self.state != "PLAYING":
            return

        self.level_time -= dt
        if self.message_timer > 0:
            self.message_timer -= dt
            if self.message_timer <= 0:
                self.message = ""

        if self.level_time <= 0:
            self.state = "GAME_OVER"
            self.message = "Time Up!"
            self.message_timer = 2.0
            return

        self.enemy_move_timer -= dt
        if self.enemy_move_timer <= 0:
            self.enemy_step()
            self.enemy_move_timer = max(0.18, 0.9 / self.maze.enemy_speed)

        if self.player_pos == self.enemy_pos:
            self.health -= 1
            self.player_pos = self.maze.player_start
            self.enemy_pos = self.maze.enemy_start
            self.message = "Enemy caught you!"
            self.message_timer = 1.5
            if self.health <= 0:
                self.state = "GAME_OVER"

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
                return

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if self.state == "MENU":
                    if self.play_rect.collidepoint(event.pos):
                        self.start_game()
                    elif self.quit_rect.collidepoint(event.pos):
                        self.running = False
                    elif self.how_rect.collidepoint(event.pos):
                        self.state = "HOW_TO_PLAY"
                    elif self.ai_rect.collidepoint(event.pos):
                        self.state = "AI_INFO"
                elif self.state == "GAME_OVER":
                    if self.retry_rect.collidepoint(event.pos):
                        self.start_game()
                elif self.state == "WIN":
                    if self.retry_rect.collidepoint(event.pos):
                        self.start_game()
                elif self.state == "LEVEL_COMPLETE":
                    if self.next_rect.collidepoint(event.pos):
                        self.advance_level()
                continue

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                    return

                if self.state == "MENU":
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        self.start_game()
                    elif event.key == pygame.K_q:
                        self.running = False
                    continue

                if self.state == "HOW_TO_PLAY":
                    if event.key == pygame.K_ESCAPE:
                        self.state = "MENU"
                    continue

                if self.state == "AI_INFO":
                    if event.key == pygame.K_ESCAPE:
                        self.state = "MENU"
                    continue

                if self.state == "PLAYING":
                    if event.key in (pygame.K_w, pygame.K_UP):
                        self.move_player(0, -1)
                    elif event.key in (pygame.K_s, pygame.K_DOWN):
                        self.move_player(0, 1)
                    elif event.key in (pygame.K_a, pygame.K_LEFT):
                        self.move_player(-1, 0)
                    elif event.key in (pygame.K_d, pygame.K_RIGHT):
                        self.move_player(1, 0)
                    elif event.key == pygame.K_p:
                        self.show_enemy_path = not self.show_enemy_path
                    continue

                if self.state == "LEVEL_COMPLETE":
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        self.advance_level()
                    continue

                if self.state in ("GAME_OVER", "WIN"):
                    if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                        self.start_game()
                    elif event.key == pygame.K_q:
                        self.running = False
                    continue

    def draw_button(self, label, rect, color):
        pygame.draw.rect(self.screen, color, rect, border_radius=12)
        pygame.draw.rect(self.screen, (255, 255, 255), rect, 2, border_radius=12)
        text = self.font_sub.render(label, True, (255, 255, 255))
        self.screen.blit(text, (rect.centerx - text.get_width() // 2, rect.centery - text.get_height() // 2))

    def draw_text(self, text, font, color, x, y):
        rendered = font.render(text, True, color)
        self.screen.blit(rendered, (x - rendered.get_width() // 2, y))

    def draw_menu(self):
        self.screen.fill((9, 12, 18))
        self.draw_text("AI MAZE ESCAPE", self.font_title, (255, 255, 255), WIDTH // 2, 100)
        self.draw_text("Collect all keys and escape the maze.", self.font_body, (150, 200, 255), WIDTH // 2, 160)

        self.play_rect = pygame.Rect(WIDTH // 2 - 150, 240, 300, 55)
        self.how_rect = pygame.Rect(WIDTH // 2 - 150, 320, 300, 55)
        self.ai_rect = pygame.Rect(WIDTH // 2 - 150, 400, 300, 55)
        self.quit_rect = pygame.Rect(WIDTH // 2 - 150, 480, 300, 55)

        self.draw_button("PLAY GAME", self.play_rect, (35, 130, 110))
        self.draw_button("HOW TO PLAY", self.how_rect, (55, 90, 150))
        self.draw_button("AI INFORMATION", self.ai_rect, (70, 90, 130))
        self.draw_button("QUIT", self.quit_rect, (140, 60, 60))

    def draw_how_to_play(self):
        self.screen.fill((12, 16, 22))
        self.draw_text("HOW TO PLAY", self.font_title, (255, 255, 255), WIDTH // 2, 60)
        lines = [
            "W / A / S / D or Arrow Keys = Move",
            "Collect all the required keys.",
            "Avoid the AI enemy.",
            "Reach the exit after collecting all keys.",
            "Press ESC to return to the menu.",
        ]

        y = 160
        for line in lines:
            text = self.font_body.render(line, True, (220, 235, 255))
            self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, y))
            y += 50

    def draw_ai_info(self):
        self.screen.fill((12, 16, 22))
        self.draw_text("AI INFORMATION", self.font_title, (255, 255, 255), WIDTH // 2, 60)
        lines = [
            "AI Algorithm: A* Search Algorithm",
            "The enemy uses A* to find the best path to the player.",
            "A* uses G cost, H cost, and F cost.",
            "H cost uses Manhattan distance.",
            "This helps the enemy avoid walls and chase the player.",
            "Press ESC to return to the menu.",
        ]

        y = 180
        for line in lines:
            text = self.font_body.render(line, True, (220, 235, 255))
            self.screen.blit(text, (WIDTH // 2 - text.get_width() // 2, y))
            y += 46

    def draw_game(self):
        self.screen.fill((9, 12, 18))

        hud = [
            f"LEVEL: {self.current_level}",
            f"SCORE: {self.score}",
            f"HEALTH: {self.health}",
            f"KEYS: {self.key_count}/{self.maze.required_keys}",
            f"REQUIRED: {self.maze.required_keys}",
            f"TIME: {int(self.level_time)}",
            f"AI: {self.enemy_status}",
        ]

        x = 25
        y = 15
        for item in hud:
            text = self.font_small.render(item, True, (255, 255, 255))
            self.screen.blit(text, (x, y))
            x += 120

        self.maze.draw(self.screen, self.player_pos, self.enemy_pos, self.collected_keys)

        if self.message:
            msg = self.font_body.render(self.message, True, (255, 255, 255))
            self.screen.blit(msg, (WIDTH // 2 - msg.get_width() // 2, 620))

        if self.show_enemy_path and self.enemy_path:
            for cell in self.enemy_path:
                px = OFFSET_X + cell[0] * TILE_SIZE + TILE_SIZE // 2
                py = OFFSET_Y + cell[1] * TILE_SIZE + TILE_SIZE // 2
                pygame.draw.circle(self.screen, (255, 255, 0), (px, py), 4)

    def draw_level_complete(self):
        self.screen.fill((10, 20, 15))
        self.draw_text("LEVEL COMPLETE!", self.font_title, (140, 255, 200), WIDTH // 2, 180)
        self.draw_text(f"Score: {self.score}", self.font_sub, (255, 255, 255), WIDTH // 2, 250)
        self.next_rect = pygame.Rect(WIDTH // 2 - 150, 330, 300, 60)
        self.draw_button("NEXT LEVEL", self.next_rect, (60, 150, 110))

    def draw_game_over(self):
        self.screen.fill((25, 12, 12))
        self.draw_text("GAME OVER", self.font_title, (255, 110, 110), WIDTH // 2, 180)
        self.draw_text(f"Final Score: {self.score}", self.font_sub, (255, 255, 255), WIDTH // 2, 250)
        self.retry_rect = pygame.Rect(WIDTH // 2 - 150, 330, 300, 60)
        self.draw_button("PLAY AGAIN", self.retry_rect, (180, 70, 70))

    def draw_win(self):
        self.screen.fill((16, 12, 24))
        self.draw_text("YOU WON!", self.font_title, (255, 210, 120), WIDTH // 2, 180)
        self.draw_text(f"Final Score: {self.score}", self.font_sub, (255, 255, 255), WIDTH // 2, 250)
        self.retry_rect = pygame.Rect(WIDTH // 2 - 150, 330, 300, 60)
        self.draw_button("PLAY AGAIN", self.retry_rect, (80, 120, 220))

    def draw(self):
        if self.state == "MENU":
            self.draw_menu()
        elif self.state == "HOW_TO_PLAY":
            self.draw_how_to_play()
        elif self.state == "AI_INFO":
            self.draw_ai_info()
        elif self.state == "PLAYING":
            self.draw_game()
        elif self.state == "LEVEL_COMPLETE":
            self.draw_level_complete()
        elif self.state == "GAME_OVER":
            self.draw_game_over()
        elif self.state == "WIN":
            self.draw_win()

        pygame.display.flip()

    def run(self):
        while self.running:
            dt = self.clock.tick(60) / 1000.0
            self.handle_events()
            self.update(dt)
            self.draw()

        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    game = Game()
    game.run()
