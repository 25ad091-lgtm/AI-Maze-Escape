cd "C:\Users\shrut\OneDrive\Documents\ai game\AI_Maze_Escape"
python main.pyclass Player:
    def __init__(self, start_pos):
        self.pos = start_pos
        self.score = 0
        self.health = 3
        self.keys_collected = 0

    def move(self, dx, dy, maze):
        new_pos = (self.pos[0] + dy, self.pos[1] + dx)
        if maze.is_walkable(new_pos):
            self.pos = new_pos
            return True
        return False

    def reset_to_start(self, start_pos):
        self.pos = start_pos

    def draw(self, screen, cell_size, offset_x, offset_y, color=(85, 180, 255)):
        px = offset_x + self.pos[1] * cell_size + cell_size // 2
        py = offset_y + self.pos[0] * cell_size + cell_size // 2
        radius = cell_size // 2 - 5
        pygame = __import__('pygame')
        pygame.draw.circle(screen, color, (px, py), radius)
        pygame.draw.circle(screen, (255, 255, 255), (px - 5, py - 5), 4)
